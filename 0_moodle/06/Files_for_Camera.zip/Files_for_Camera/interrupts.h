/*
 * interrupts.h
 *
 *  Created on: Mar 30, 2013
 *      Author: theo
 */

#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

unsigned int get_picture_count();

#endif /* INTERRUPTS_H_ */
